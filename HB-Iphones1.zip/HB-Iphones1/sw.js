const CACHE_VERSION = 'hb-cache-v1';
const CORE_ASSETS = [
  './',
  './index.html',
  './offline.html',
  './assets/css/styles.css',
  './assets/js/main.js',
  './manifest.json'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_VERSION).then((cache) => cache.addAll(CORE_ASSETS)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.map((k) => (k !== CACHE_VERSION ? caches.delete(k) : null)))).then(() => self.clients.claim())
  );
});

// Estratégia: navigation = network-first com fallback offline; assets = cache-first
self.addEventListener('fetch', (event) => {
  const req = event.request;

  // Navegações (páginas)
  if (req.mode === 'navigate') {
    event.respondWith(
      fetch(req).catch(() => caches.match('./offline.html'))
    );
    return;
  }

  const url = new URL(req.url);
  const isAsset = /\.(?:css|js|png|jpg|jpeg|webp|svg|ico|woff2?)$/i.test(url.pathname);

  if (isAsset) {
    event.respondWith(
      caches.match(req).then((cached) => {
        const fetchAndCache = fetch(req).then((res) => {
          const copy = res.clone();
          caches.open(CACHE_VERSION).then((cache) => cache.put(req, copy));
          return res;
        }).catch(() => cached);
        return cached || fetchAndCache;
      })
    );
  }
});
