// Configurações (100% estático)
const WHATSAPP_NUMBER = "+55 31 8495-9023"; // número real da HB iPhones Ouro Branco
const WHATSAPP_LINK = `https://wa.me/${WHATSAPP_NUMBER.replace(/\D/g, '')}?text=Olá%20HB%20iPhones%2C%20tenho%20interesse!`;
const INSTALLMENTS = 12; // padrão 12x

// Menu mobile
const burger = document.querySelector('[data-burger]');
const menu = document.querySelector('[data-menu]');
if (burger) {
  burger.addEventListener('click', () => {
    menu?.classList.toggle('open');
  });
}

// (Sem dependência de API) – o site funciona 100% estático

// Analytics stub (GA4/others)
window.dataLayer = window.dataLayer || [];
function trackEvent(eventName, params = {}) {
  try {
    window.dataLayer.push({ event: eventName, ...params });
    if (window.console && console.debug) console.debug('[event]', eventName, params);
  } catch {}
}

// Botões WhatsApp (contextual por produto)
document.querySelectorAll('[data-whatsapp]')?.forEach(btn => {
  // Progressive enhancement: link direto
  try {
    if (btn.tagName === 'A') {
      btn.setAttribute('href', WHATSAPP_LINK);
      btn.setAttribute('target', '_blank');
      btn.setAttribute('rel', 'noopener');
    }
  } catch {}

  const buildContextLink = (sourceEl) => {
    // Detecta card de produto mais próximo
    const card = sourceEl.closest('[data-product]');
    let text = 'Olá HB iPhones! Tenho interesse.';
    const utmBase = 'utm_source=site&utm_medium=whatsapp&utm_campaign=' + encodeURIComponent(document.title || 'hb-site');
    if (card) {
      const modelo = card.getAttribute('data-modelo') || '';
      const cor = card.getAttribute('data-cor') || '';
      const arm = card.getAttribute('data-armazenamento') || '';
      const cond = card.getAttribute('data-condicao') || '';
      text = `Olá HB iPhones! Tenho interesse em ${modelo}${arm ? ', ' + arm : ''}${cor ? ', ' + cor : ''}${cond ? ' (' + cond + ')' : ''}. Vim do site.`;
    }
    const link = `https://wa.me/${WHATSAPP_NUMBER.replace(/\D/g, '')}?text=${encodeURIComponent(text)}&${utmBase}`;
    return link;
  };

  // Clique abre o WhatsApp e previne o comportamento padrão do link '#'
  btn.addEventListener('click', (e) => {
    try { e.preventDefault(); } catch {}
    const link = buildContextLink(btn);
    // analytics
    const card = btn.closest('[data-product]');
    trackEvent('whatsapp_click', {
      location: !!btn.closest('.whatsapp-fab') ? 'fab' : (card ? 'product_card' : 'generic'),
      model: card?.getAttribute('data-modelo') || undefined,
      color: card?.getAttribute('data-cor') || undefined,
      storage: card?.getAttribute('data-armazenamento') || undefined,
      condition: card?.getAttribute('data-condicao') || undefined
    });
    window.open(link, '_blank');
  });

  // Padronizar rótulo apenas para botões comuns (não para o FAB)
  const isFab = !!btn.closest('.whatsapp-fab');
  if (!isFab) {
    try { btn.textContent = 'Consultar no WhatsApp'; } catch {}
  }
});

// Lazy-loading de imagens não críticas (performance)
(() => {
  const isHeroImage = (img) => {
    // Heurística simples: imagens dentro de .hero ou primeiras na página
    return img.closest('.hero') || img.getBoundingClientRect().top < (window.innerHeight * 0.75);
  };
  const imgs = Array.from(document.querySelectorAll('img'));
  imgs.forEach(img => {
    try {
      img.decoding = 'async';
      if (!isHeroImage(img)) {
        if (!img.hasAttribute('loading')) img.setAttribute('loading', 'lazy');
      }
    } catch {}
  });
  // Definir sizes responsivo com base na grid
  const setSizesForGrid = (selector, sizes) => {
    document.querySelectorAll(selector + ' img').forEach(img => {
      try { img.setAttribute('sizes', sizes); } catch {}
    });
  };
  setSizesForGrid('.grid.cols-4', '(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw');
  setSizesForGrid('.grid.cols-3', '(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw');
})();

// Pulse discreto no FAB do WhatsApp (apenas uma vez no load e uma na primeira rolagem)
(() => {
  const fab = document.querySelector('.whatsapp-fab');
  if (!fab) return;

  const pulseOnce = () => {
    if (fab.classList.contains('pulse')) return;
    fab.classList.add('pulse');
    const a = fab.querySelector('a');
    const onEnd = () => {
      fab.classList.remove('pulse');
      a?.removeEventListener('animationend', onEnd);
    };
    a?.addEventListener('animationend', onEnd);
  };

  // Pulse após o carregamento, com leve atraso
  window.setTimeout(pulseOnce, 1400);

  // Pulse na primeira rolagem além de 200px
  let pulsedOnScroll = false;
  window.addEventListener('scroll', () => {
    if (pulsedOnScroll) return;
    if (window.scrollY > 200) {
      pulseOnce();
      pulsedOnScroll = true;
    }
  }, { passive: true });
})();

// Tooltip dinâmico do FAB conforme horário
(() => {
  const fabA = document.querySelector('.whatsapp-fab a[data-tooltip]');
  if (!fabA) return;
  try {
    const now = new Date();
    const day = now.getDay(); // 0 Dom ... 6 Sáb
    const h = now.getHours();
    const isWeekday = day >= 1 && day <= 5;
    const isSaturday = day === 6;
    const open = (isWeekday && h >= 9 && h < 18) || (isSaturday && h >= 9 && h < 13);
    fabA.setAttribute('data-tooltip', open ? 'Falar agora no WhatsApp' : 'Deixe sua mensagem no WhatsApp');
  } catch {}
})();

// JSON-LD de produtos (SEO básico)
(() => {
  const cards = Array.from(document.querySelectorAll('[data-product]'));
  if (!cards.length) return;
  const items = cards.map(card => {
    const name = card.getAttribute('data-modelo') || 'Produto';
    const cond = card.getAttribute('data-condicao') || '';
    const priceAttr = card.querySelector('[data-price]');
    const price = priceAttr ? priceAttr.getAttribute('data-price') : undefined;
    const obj = {
      '@type': 'Product',
      name,
      category: cond || 'Electronics',
      url: window.location.href
    };
    if (price) {
      obj.offers = {
        '@type': 'Offer',
        priceCurrency: 'BRL',
        price: price,
        availability: 'https://schema.org/InStock',
        url: window.location.href
      };
    }
    return obj;
  });
  const ld = {
    '@context': 'https://schema.org',
    '@type': 'ItemList',
    itemListElement: items
  };
  const script = document.createElement('script');
  script.type = 'application/ld+json';
  script.text = JSON.stringify(ld);
  document.body.appendChild(script);
})();

// Cálculo de parcelamento a partir de data-price (valor à vista em R$)
document.querySelectorAll('[data-price]')?.forEach(el => {
  const raw = parseFloat(el.getAttribute('data-price'));
  if (!isNaN(raw) && INSTALLMENTS > 1) {
    const per = raw / INSTALLMENTS;
    const target = el.parentElement?.querySelector('[data-installments]');
    if (target) {
      target.textContent = `${INSTALLMENTS}x de R$ ${per.toFixed(2).replace('.', ',')}`;
    }
  }
});

// Scroll Reveal simples
const revealEls = Array.from(document.querySelectorAll('[data-reveal]'));
if (revealEls.length) {
  const onScroll = () => {
    const vh = window.innerHeight || document.documentElement.clientHeight;
    revealEls.forEach(el => {
      if (el.classList.contains('revealed')) return;
      const rect = el.getBoundingClientRect();
      if (rect.top < vh * 0.9) {
        el.classList.add('revealed');
      }
    });
  };
  window.addEventListener('scroll', onScroll, { passive: true });
  window.addEventListener('load', onScroll);
  onScroll();
}

// Filtros de produtos (página Produtos)
const filterForm = document.querySelector('[data-filter-form]');
if (filterForm) {
  filterForm.addEventListener('input', () => {
    const cards = document.querySelectorAll('[data-product]');
    const model = filterForm.querySelector('[name="modelo"]').value.toLowerCase();
    const cor = filterForm.querySelector('[name="cor"]').value.toLowerCase();
    const armazenamento = filterForm.querySelector('[name="armazenamento"]').value.toLowerCase();
    const condicao = filterForm.querySelector('[name="condicao"]').value.toLowerCase();

    cards.forEach(card => {
      const d = {
        modelo: card.getAttribute('data-modelo')?.toLowerCase() || '',
        cor: card.getAttribute('data-cor')?.toLowerCase() || '',
        armazenamento: card.getAttribute('data-armazenamento')?.toLowerCase() || '',
        condicao: card.getAttribute('data-condicao')?.toLowerCase() || ''
      };
      const ok = (!model || d.modelo.includes(model)) &&
                 (!cor || d.cor.includes(cor)) &&
                 (!armazenamento || d.armazenamento.includes(armazenamento)) &&
                 (!condicao || d.condicao.includes(condicao));
      card.style.display = ok ? '' : 'none';
    });
    trackEvent('filter_apply', { model, color: cor, storage: armazenamento, condition: condicao });
  });
}

// Categorias (página Produtos): botões [data-category-btn] alternam [data-category]
const catButtons = document.querySelectorAll('[data-category-btn]');
const catSections = document.querySelectorAll('[data-category]');
if (catButtons.length && catSections.length) {
  catButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.getAttribute('data-category-btn');
      // estado visual
      catButtons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      // mostrar/ocultar
      catSections.forEach(sec => {
        sec.style.display = sec.getAttribute('data-category') === target ? '' : 'none';
      });
      trackEvent('category_select', { category: target });
    });
  });
}

// Integração Instagram opcional via widget: só se houver data-embed com URL
const insta = document.querySelector('[data-instagram-embed]');
if (insta) {
  const embedUrl = insta.getAttribute('data-embed');
  if (embedUrl) {
    const iframe = document.createElement('iframe');
    iframe.loading = 'lazy';
    iframe.referrerPolicy = 'no-referrer-when-downgrade';
    iframe.style.width = '100%';
    iframe.style.height = '520px';
    iframe.style.border = '0';
    iframe.style.borderRadius = '14px';
    iframe.src = embedUrl; // URL fornecida por SnapWidget/Elfsight/LightWidget
    insta.appendChild(iframe);
  }
}

// Comparador Antes/Depois (página Serviços)
document.querySelectorAll('[data-compare]')?.forEach(wrapper => {
  const after = wrapper.querySelector('[data-compare-after]');
  const range = wrapper.querySelector('[data-compare-range]');
  if (after && range) {
    const update = () => {
      const v = parseInt(range.value, 10);
      after.style.clipPath = `inset(0 ${100 - v}% 0 0)`;
    };
    range.addEventListener('input', update);
    update();
  }
});
