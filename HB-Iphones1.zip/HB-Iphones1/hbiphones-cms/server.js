import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import helmet from 'helmet';
import morgan from 'morgan';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import bodyParser from 'body-parser';
import cookieParser from 'cookie-parser';
import sequelize from './src/db/sequelize.js';

import authRoutes from './src/routes/auth.js';
import productRoutes from './src/routes/products.js';
import benefitRoutes from './src/routes/benefits.js';
import testimonialRoutes from './src/routes/testimonials.js';
import configRoutes from './src/routes/config.js';
import adminRoutes from './src/routes/admin.js';

dotenv.config();

const app = express();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Conexão MySQL via Sequelize será iniciada antes de app.listen

// View engine e caminhos estáticos
app.set('views', path.join(__dirname, 'src', 'views'));
app.set('view engine', 'ejs');
app.use('/public', express.static(path.join(__dirname, 'public')));

// Middlewares globais
app.use(helmet());
app.use(morgan('dev'));
app.use(cors({ origin: '*'}));
app.use(bodyParser.json({ limit: '10mb' }));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());

// Rate limiting
const apiLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 300 });
app.use('/api/', apiLimiter);

// Rotas API públicas
app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);
app.use('/api/benefits', benefitRoutes);
app.use('/api/testimonials', testimonialRoutes);
app.use('/api/config', configRoutes);

// Rotas Admin (EJS)
app.use('/admin', adminRoutes);

// Rota raiz simples
app.get('/', (req, res) => {
  res.json({ message: 'HB iPhones CMS API rodando', docs: '/admin' });
});

// 404
app.use((req, res) => {
  if (req.path.startsWith('/admin')) {
    return res.status(404).render('404', { title: 'Página não encontrada' });
  }
  return res.status(404).json({ error: 'Not Found' });
});

const PORT = process.env.PORT || 3000;

async function start() {
  try {
    await sequelize.authenticate();
    await sequelize.sync();
    console.log('MySQL conectado e modelos sincronizados');
    app.listen(PORT, () => console.log(`Servidor rodando em http://localhost:${PORT}`));
  } catch (err) {
    console.error('Erro ao conectar no MySQL:', err.message);
    process.exit(1);
  }
}

start();
