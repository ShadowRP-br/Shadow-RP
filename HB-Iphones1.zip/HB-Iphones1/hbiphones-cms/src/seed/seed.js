import dotenv from 'dotenv';
import bcrypt from 'bcryptjs';
import sequelize from '../db/sequelize.js';
import User from '../models/User.js';
import Product from '../models/Product.js';
import Benefit from '../models/Benefit.js';
import Testimonial from '../models/Testimonial.js';
import Config from '../models/Config.js';

dotenv.config();

async function run() {
  try {
    await sequelize.authenticate();
    console.log('Conectado ao MySQL');
    await sequelize.sync({ force: true });
    console.log('Tabelas sincronizadas (force: true)');

    console.log('Criando usuário admin e editor...');
    await User.bulkCreate([
      { name: 'Administrador', email: 'admin@hbiphones.com', password: await bcrypt.hash('admin123', 10), role: 'admin' },
      { name: 'Editor', email: 'editor@hbiphones.com', password: await bcrypt.hash('editor123', 10), role: 'editor' },
    ]);

    console.log('Inserindo Config inicial...');
    await Config.create({
      headerText: 'Seu iPhone com qualidade e confiança em Ouro Branco',
      whatsappNumber: process.env.WHATSAPP_NUMBER || '5531999999999',
      instagram: '@hbiphonesourobranco',
      address: 'Ouro Branco, MG',
      city: 'Ouro Branco',
      state: 'MG',
      banners: [],
      about: 'Loja especializada em iPhones novos e seminovos, acessórios e assistência técnica em Ouro Branco, MG.'
    });

    console.log('Inserindo Produtos...');
    await Product.bulkCreate([
      { name: 'iPhone 15 Pro', category: 'iPhones novos', type: 'novo', capacity: '256GB', price: 8999, description: 'Desempenho extremo e design premium.', images: ['/public/uploads/iphone15pro.jpg'] },
      { name: 'iPhone 14 seminovo', category: 'seminovos', type: 'usado', capacity: '128GB', price: 4299, description: 'Excelente estado, seminovo com garantia.', images: ['/public/uploads/iphone14-seminovo.jpg'] },
      { name: 'AirPods Pro', category: 'acessórios', type: 'novo', capacity: '', price: 1899, description: 'Cancelamento de ruído ativo.', images: ['/public/uploads/airpodspro.jpg'] },
      { name: 'iPhone 13 seminovo', category: 'seminovos', type: 'usado', capacity: '128GB', price: 3799, description: 'Ótimo custo-benefício.', images: ['/public/uploads/iphone13-seminovo.jpg'] },
    ]);

    console.log('Inserindo Benefícios...');
    await Benefit.bulkCreate([
      { title: 'Garantia', description: 'Garantia de procedência e suporte.' },
      { title: 'Atendimento especializado', description: 'Equipe pronta para ajudar.' },
      { title: 'Opções de pagamento', description: 'Cartão, Pix e parcelamento.' },
    ]);

    console.log('Inserindo Depoimentos...');
    await Testimonial.bulkCreate([
      { clientName: 'Ana Souza', rating: 5, quote: 'Comprei meu iPhone com a HB e foi tudo perfeito!' },
      { clientName: 'João Lima', rating: 5, quote: 'Excelente atendimento e produto top!' },
      { clientName: 'Mariana Alves', rating: 4, quote: 'Entrega rápida e tudo certinho.' },
    ]);

    console.log('Seed concluído com MySQL.');
    process.exit(0);
  } catch (e) {
    console.error('Erro no seed:', e);
    process.exit(1);
  }
}

run();
