import { body } from 'express-validator';

export const validateProduct = [
  body('name').notEmpty().withMessage('Nome é obrigatório'),
  body('category').isIn(['iPhones novos', 'seminovos', 'acessórios']).withMessage('Categoria inválida'),
  body('type').isIn(['novo', 'usado']).withMessage('Tipo inválido'),
  body('price').isFloat({ min: 0 }).withMessage('Preço inválido'),
];

export const validateAuth = [
  body('email').isEmail().withMessage('E-mail inválido'),
  body('password').isLength({ min: 6 }).withMessage('Senha deve ter ao menos 6 caracteres'),
];
