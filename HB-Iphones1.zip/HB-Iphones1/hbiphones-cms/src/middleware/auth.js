import jwt from 'jsonwebtoken';

export const authenticate = (req, res, next) => {
  const authHeader = req.headers.authorization || req.cookies?.token;
  let token = null;
  if (authHeader?.startsWith('Bearer ')) token = authHeader.split(' ')[1];
  if (!token && req.cookies?.token) token = req.cookies.token;
  if (!token) return res.status(401).json({ error: 'Token não fornecido' });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Token inválido' });
  }
};

export const authorize = (...roles) => (req, res, next) => {
  if (!req.user) return res.status(401).json({ error: 'Não autenticado' });
  if (!roles.includes(req.user.role)) return res.status(403).json({ error: 'Sem permissão' });
  next();
};
