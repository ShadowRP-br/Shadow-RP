import { DataTypes } from 'sequelize';
import sequelize from '../db/sequelize.js';

const Product = sequelize.define('Product', {
  id: { type: DataTypes.INTEGER.UNSIGNED, autoIncrement: true, primaryKey: true },
  name: { type: DataTypes.STRING(180), allowNull: false },
  category: { type: DataTypes.ENUM('iPhones novos', 'seminovos', 'acessórios'), allowNull: false },
  type: { type: DataTypes.ENUM('novo', 'usado'), allowNull: false },
  capacity: { type: DataTypes.STRING(50), allowNull: true },
  price: { type: DataTypes.FLOAT.UNSIGNED, allowNull: false },
  description: { type: DataTypes.TEXT, allowNull: true },
  images: { type: DataTypes.JSON, allowNull: false, defaultValue: [] },
  status: { type: DataTypes.ENUM('ativo', 'inativo'), allowNull: false, defaultValue: 'ativo' },
  views: { type: DataTypes.INTEGER.UNSIGNED, allowNull: false, defaultValue: 0 },
}, {
  tableName: 'products',
  timestamps: true,
});

export default Product;
