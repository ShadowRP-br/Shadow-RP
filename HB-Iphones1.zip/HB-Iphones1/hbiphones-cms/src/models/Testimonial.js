import { DataTypes } from 'sequelize';
import sequelize from '../db/sequelize.js';

const Testimonial = sequelize.define('Testimonial', {
  id: { type: DataTypes.INTEGER.UNSIGNED, autoIncrement: true, primaryKey: true },
  clientName: { type: DataTypes.STRING(150), allowNull: false },
  rating: { type: DataTypes.INTEGER.UNSIGNED, allowNull: false, validate: { min: 1, max: 5 } },
  quote: { type: DataTypes.TEXT, allowNull: false },
  clientImage: { type: DataTypes.STRING(255), allowNull: true },
}, {
  tableName: 'testimonials',
  timestamps: true,
});

export default Testimonial;
