import { DataTypes } from 'sequelize';
import sequelize from '../db/sequelize.js';

const Config = sequelize.define('Config', {
  id: { type: DataTypes.INTEGER.UNSIGNED, autoIncrement: true, primaryKey: true },
  headerText: { type: DataTypes.STRING(255), allowNull: false, defaultValue: 'Seu iPhone com qualidade e confiança em Ouro Branco' },
  whatsappNumber: { type: DataTypes.STRING(30), allowNull: false, default: '' },
  instagram: { type: DataTypes.STRING(80), allowNull: true, defaultValue: '@hbiphonesourobranco' },
  address: { type: DataTypes.STRING(200), allowNull: true, defaultValue: 'Ouro Branco, MG' },
  city: { type: DataTypes.STRING(100), allowNull: true, defaultValue: 'Ouro Branco' },
  state: { type: DataTypes.STRING(5), allowNull: true, defaultValue: 'MG' },
  logo: { type: DataTypes.STRING(255), allowNull: true },
  banners: { type: DataTypes.JSON, allowNull: false, defaultValue: [] },
  about: { type: DataTypes.TEXT, allowNull: true, defaultValue: '' },
}, {
  tableName: 'configs',
  timestamps: true,
});

export default Config;
