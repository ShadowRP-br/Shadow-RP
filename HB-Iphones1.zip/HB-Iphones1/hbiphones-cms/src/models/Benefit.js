import { DataTypes } from 'sequelize';
import sequelize from '../db/sequelize.js';

const Benefit = sequelize.define('Benefit', {
  id: { type: DataTypes.INTEGER.UNSIGNED, autoIncrement: true, primaryKey: true },
  title: { type: DataTypes.STRING(180), allowNull: false },
  description: { type: DataTypes.TEXT, allowNull: true },
  icon: { type: DataTypes.STRING(255), allowNull: true },
  order: { type: DataTypes.INTEGER.UNSIGNED, allowNull: false, defaultValue: 0 },
}, {
  tableName: 'benefits',
  timestamps: true,
});

export default Benefit;
