import { Sequelize } from 'sequelize';
import dotenv from 'dotenv';

dotenv.config();

const {
  MYSQL_HOST = 'localhost',
  MYSQL_PORT = '3306',
  MYSQL_USER = 'root',
  MYSQL_PASS = '',
  MYSQL_DB = 'hbiphones'
} = process.env;

export const sequelize = new Sequelize(MYSQL_DB, MYSQL_USER, MYSQL_PASS, {
  host: MYSQL_HOST,
  port: Number(MYSQL_PORT),
  dialect: 'mysql',
  logging: false,
});

export default sequelize;
