import { Router } from 'express';
import { authenticate, authorize } from '../middleware/auth.js';
import { upload } from '../middleware/upload.js';
import * as ctrl from '../controllers/testimonialController.js';

const router = Router();
router.get('/', ctrl.list);
router.post('/', authenticate, authorize('admin', 'editor'), upload.single('clientImage'), ctrl.create);
router.put('/:id', authenticate, authorize('admin', 'editor'), upload.single('clientImage'), ctrl.update);
router.delete('/:id', authenticate, authorize('admin'), ctrl.remove);
export default router;
