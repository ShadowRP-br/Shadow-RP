import { Router } from 'express';
import { authenticate, authorize } from '../middleware/auth.js';
import { upload } from '../middleware/upload.js';
import { validateProduct } from '../middleware/validation.js';
import * as product from '../controllers/productController.js';

const router = Router();

router.get('/', product.list);
router.get('/:id', product.getOne);

router.post('/', authenticate, authorize('admin', 'editor'), upload.array('images', 6), validateProduct, product.create);
router.put('/:id', authenticate, authorize('admin', 'editor'), upload.array('images', 6), product.update);
router.delete('/:id', authenticate, authorize('admin'), product.remove);

export default router;
