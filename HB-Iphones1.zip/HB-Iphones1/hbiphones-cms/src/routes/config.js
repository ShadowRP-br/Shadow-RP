import { Router } from 'express';
import { authenticate, authorize } from '../middleware/auth.js';
import { upload } from '../middleware/upload.js';
import * as ctrl from '../controllers/configController.js';

const router = Router();
router.get('/', ctrl.getConfig);
router.put('/', authenticate, authorize('admin'), upload.array('banners', 5), ctrl.updateConfig);
export default router;
