import { Router } from 'express';
import { login } from '../controllers/authController.js';
import { validateAuth } from '../middleware/validation.js';

const router = Router();
router.post('/login', validateAuth, login);
export default router;
