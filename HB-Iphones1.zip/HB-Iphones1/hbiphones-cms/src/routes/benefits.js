import { Router } from 'express';
import { authenticate, authorize } from '../middleware/auth.js';
import { upload } from '../middleware/upload.js';
import * as ctrl from '../controllers/benefitController.js';

const router = Router();
router.get('/', ctrl.list);
router.post('/', authenticate, authorize('admin', 'editor'), upload.single('icon'), ctrl.create);
router.put('/:id', authenticate, authorize('admin', 'editor'), upload.single('icon'), ctrl.update);
router.delete('/:id', authenticate, authorize('admin'), ctrl.remove);
export default router;
