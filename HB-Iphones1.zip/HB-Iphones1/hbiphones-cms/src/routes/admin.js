import { Router } from 'express';
import { authenticate, authorize } from '../middleware/auth.js';
import { dashboard, generate } from '../controllers/adminController.js';
import { renderLogin, postLogin, logout } from '../controllers/adminAuthController.js';

const router = Router();

// Rotas públicas do admin (login/logout)
router.get('/login', renderLogin);
router.post('/login', postLogin);
router.get('/logout', logout);

// Middleware para rotas protegidas (usa JWT em header ou cookie)
router.use(authenticate, authorize('admin', 'editor'));

router.get('/', dashboard);
router.post('/generate', authorize('admin'), generate);

export default router;
