import { Router } from 'express';
import { authenticate, authorize } from '../middleware/auth.js';
import * as ctrl from '../controllers/serviceController.js';

const router = Router();
router.get('/', ctrl.list);
router.post('/', authenticate, authorize('admin', 'editor'), ctrl.create);
router.put('/:id', authenticate, authorize('admin', 'editor'), ctrl.update);
router.delete('/:id', authenticate, authorize('admin'), ctrl.remove);
router.post('/schedule', ctrl.schedule);
export default router;
