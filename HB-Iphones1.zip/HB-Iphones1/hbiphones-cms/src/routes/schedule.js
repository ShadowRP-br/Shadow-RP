import { Router } from 'express';
import { schedule } from '../controllers/serviceController.js';

const router = Router();
router.post('/', schedule);
export default router;
