import { validationResult } from 'express-validator';
import { Op } from 'sequelize';
import Product from '../models/Product.js';

export const list = async (req, res) => {
  try {
    const { page = 1, limit = 5, q = '', category } = req.query;
    const where = { status: 'ativo' };
    if (q) where.name = { [Op.like]: `%${q}%` };
    if (category) where.category = category;

    const offset = (Number(page) - 1) * Number(limit);
    const { rows, count } = await Product.findAndCountAll({
      where,
      order: [['createdAt', 'DESC']],
      offset,
      limit: Number(limit),
    });
    res.json({ items: rows, total: count, page: Number(page), pages: Math.ceil(count / Number(limit)) });
  } catch (e) {
    res.status(500).json({ error: 'Erro ao listar produtos' });
  }
};

export const getOne = async (req, res) => {
  try {
    const item = await Product.findByPk(req.params.id);
    if (!item) return res.status(404).json({ error: 'Produto não encontrado' });
    res.json(item);
  } catch (e) {
    res.status(500).json({ error: 'Erro ao buscar produto' });
  }
};

export const create = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
  try {
    const images = (req.files || []).map((f) => `/public/uploads/${f.filename}`);
    const product = await Product.create({ ...req.body, images });
    res.status(201).json(product);
  } catch (e) {
    res.status(500).json({ error: 'Erro ao criar produto' });
  }
};

export const update = async (req, res) => {
  try {
    const product = await Product.findByPk(req.params.id);
    if (!product) return res.status(404).json({ error: 'Produto não encontrado' });
    const imagesNew = (req.files || []).map((f) => `/public/uploads/${f.filename}`);
    const body = { ...req.body };
    if (imagesNew.length) {
      const current = Array.isArray(product.images) ? product.images : [];
      body.images = [...current, ...imagesNew];
    }
    await product.update(body);
    res.json(product);
  } catch (e) {
    res.status(500).json({ error: 'Erro ao atualizar produto' });
  }
};

export const remove = async (req, res) => {
  try {
    const deleted = await Product.destroy({ where: { id: req.params.id } });
    if (!deleted) return res.status(404).json({ error: 'Produto não encontrado' });
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: 'Erro ao remover produto' });
  }
};
