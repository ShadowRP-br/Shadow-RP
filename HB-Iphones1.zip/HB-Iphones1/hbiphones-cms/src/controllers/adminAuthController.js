import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import User from '../models/User.js';

export const renderLogin = (req, res) => {
  // Se já tiver cookie válido, redireciona
  const token = req.cookies?.token;
  if (token) {
    try {
      jwt.verify(token, process.env.JWT_SECRET);
      return res.redirect('/admin');
    } catch {}
  }
  return res.render('login', { title: 'Login' });
};

export const postLogin = async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email });
    if (!user) return res.render('login', { title: 'Login', error: 'Credenciais inválidas' });
    const ok = await bcrypt.compare(password, user.password);
    if (!ok) return res.render('login', { title: 'Login', error: 'Credenciais inválidas' });

    const token = jwt.sign({ id: user._id, email: user.email, role: user.role }, process.env.JWT_SECRET, { expiresIn: '8h' });
    res.cookie('token', token, {
      httpOnly: true,
      secure: false,
      sameSite: 'lax',
      maxAge: 8 * 60 * 60 * 1000,
    });
    return res.redirect('/admin');
  } catch (e) {
    return res.render('login', { title: 'Login', error: 'Erro ao autenticar' });
  }
};

export const logout = (req, res) => {
  res.clearCookie('token');
  return res.redirect('/admin/login');
};
