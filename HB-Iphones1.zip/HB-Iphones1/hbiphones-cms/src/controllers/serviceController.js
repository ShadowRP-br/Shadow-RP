import Service from '../models/Service.js';
import sendEmail from '../utils/emailSender.js';

export const list = async (req, res) => {
  try {
    const { maxPrice } = req.query;
    const filter = {};
    if (maxPrice) filter.priceApprox = { $lte: Number(maxPrice) };
    const items = await Service.find(filter).sort({ createdAt: -1 });
    res.json(items);
  } catch {
    res.status(500).json({ error: 'Erro ao listar serviços' });
  }
};

export const create = async (req, res) => {
  try {
    const item = await Service.create(req.body);
    res.status(201).json(item);
  } catch {
    res.status(500).json({ error: 'Erro ao criar serviço' });
  }
};

export const update = async (req, res) => {
  try {
    const item = await Service.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!item) return res.status(404).json({ error: 'Serviço não encontrado' });
    res.json(item);
  } catch {
    res.status(500).json({ error: 'Erro ao atualizar serviço' });
  }
};

export const remove = async (req, res) => {
  try {
    const deleted = await Service.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).json({ error: 'Serviço não encontrado' });
    res.json({ success: true });
  } catch {
    res.status(500).json({ error: 'Erro ao remover serviço' });
  }
};

export const schedule = async (req, res) => {
  try {
    const { name, email, phone, date, serviceId } = req.body;
    const service = await Service.findById(serviceId);
    if (!service) return res.status(404).json({ error: 'Serviço inválido' });

    const html = `<p>Novo agendamento:</p>
      <ul>
        <li>Nome: ${name}</li>
        <li>Email: ${email}</li>
        <li>Telefone: ${phone}</li>
        <li>Data: ${date}</li>
        <li>Serviço: ${service.name}</li>
      </ul>`;

    await sendEmail({
      to: process.env.EMAIL_USER,
      subject: 'Novo agendamento - HB iPhones',
      html,
    });

    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: 'Erro ao agendar serviço' });
  }
};
