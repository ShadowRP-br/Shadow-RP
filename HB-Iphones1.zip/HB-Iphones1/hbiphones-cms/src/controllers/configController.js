import Config from '../models/Config.js';

export const getConfig = async (req, res) => {
  try {
    let cfg = await Config.findOne();
    if (!cfg) cfg = await Config.create({});
    res.json(cfg);
  } catch (e) {
    res.status(500).json({ error: 'Erro ao buscar configurações' });
  }
};

export const updateConfig = async (req, res) => {
  try {
    let cfg = await Config.findOne();
    if (!cfg) cfg = await Config.create({});
    const bannersNew = (req.files || []).map((f) => `/public/uploads/${f.filename}`);
    const data = { ...req.body };
    if (bannersNew.length) {
      const current = Array.isArray(cfg.banners) ? cfg.banners : [];
      data.banners = [...current, ...bannersNew];
    }
    await cfg.update(data);
    res.json(cfg);
  } catch (e) {
    res.status(500).json({ error: 'Erro ao atualizar configurações' });
  }
};
