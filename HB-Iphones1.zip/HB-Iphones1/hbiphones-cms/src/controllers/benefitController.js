import Benefit from '../models/Benefit.js';

export const list = async (req, res) => {
  try {
    const items = await Benefit.findAll({ order: [['order', 'ASC'], ['createdAt', 'DESC']] });
    res.json(items);
  } catch (e) {
    res.status(500).json({ error: 'Erro ao listar benefícios' });
  }
};

export const create = async (req, res) => {
  try {
    const icon = req.file ? `/public/uploads/${req.file.filename}` : undefined;
    const item = await Benefit.create({ ...req.body, icon });
    res.status(201).json(item);
  } catch (e) {
    res.status(500).json({ error: 'Erro ao criar benefício' });
  }
};

export const update = async (req, res) => {
  try {
    const icon = req.file ? `/public/uploads/${req.file.filename}` : undefined;
    const benefit = await Benefit.findByPk(req.params.id);
    if (!benefit) return res.status(404).json({ error: 'Benefício não encontrado' });
    const data = { ...req.body };
    if (icon) data.icon = icon;
    await benefit.update(data);
    res.json(benefit);
  } catch (e) {
    res.status(500).json({ error: 'Erro ao atualizar benefício' });
  }
};

export const remove = async (req, res) => {
  try {
    const deleted = await Benefit.destroy({ where: { id: req.params.id } });
    if (!deleted) return res.status(404).json({ error: 'Benefício não encontrado' });
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: 'Erro ao remover benefício' });
  }
};
