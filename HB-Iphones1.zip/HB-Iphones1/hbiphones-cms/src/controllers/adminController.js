import Product from '../models/Product.js';
import Testimonial from '../models/Testimonial.js';
import Benefit from '../models/Benefit.js';
import Config from '../models/Config.js';
import path from 'path';
import generateStatic from '../utils/generateStatic.js';

export const dashboard = async (req, res) => {
  try {
    const [totalProducts, totalTestimonials] = await Promise.all([
      Product.count(),
      Testimonial.count(),
    ]);

    res.render('dashboard', {
      title: 'Dashboard',
      stats: {
        totalProducts,
        totalTestimonials,
        whatsappClicks: 0,
        mostViewed: [],
      },
      chartData: {
        labels: ['iPhones novos', 'seminovos', 'acessórios'],
        counts: await Promise.all([
          Product.count({ where: { category: 'iPhones novos' } }),
          Product.count({ where: { category: 'seminovos' } }),
          Product.count({ where: { category: 'acessórios' } }),
        ]),
      },
      user: req.user,
    });
  } catch (e) {
    res.status(500).send('Erro ao carregar dashboard');
  }
};

export const generate = async (req, res) => {
  try {
    let cfg = await Config.findOne();
    if (!cfg) cfg = await Config.create({});
    const [products, benefits, testimonials] = await Promise.all([
      Product.findAll({ where: { status: 'ativo' }, order: [['createdAt', 'DESC']], limit: 12 }),
      Benefit.findAll({ order: [['order', 'ASC']] }),
      Testimonial.findAll({ order: [['createdAt', 'DESC']], limit: 9 }),
    ]);

    const viewsDir = path.join(process.cwd(), 'src', 'views');
    const distDir = path.join(process.cwd(), 'dist');
    await generateStatic({
      viewsDir,
      distDir,
      template: 'static_home.ejs',
      data: { config: cfg, products, benefits, testimonials },
    });

    return res.status(200).json({ success: true, output: '/dist/index.html' });
  } catch (e) {
    console.error('Erro ao gerar site estático', e);
    return res.status(500).json({ error: 'Erro ao gerar site estático' });
  }
};
