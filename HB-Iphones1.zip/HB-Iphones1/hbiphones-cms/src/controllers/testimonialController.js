import { Op } from 'sequelize';
import Testimonial from '../models/Testimonial.js';

export const list = async (req, res) => {
  try {
    const { minRating } = req.query;
    const where = {};
    if (minRating) where.rating = { [Op.gte]: Number(minRating) };
    const items = await Testimonial.findAll({ where, order: [['createdAt', 'DESC']] });
    res.json(items);
  } catch (e) {
    res.status(500).json({ error: 'Erro ao listar depoimentos' });
  }
};

export const create = async (req, res) => {
  try {
    const clientImage = req.file ? `/public/uploads/${req.file.filename}` : undefined;
    const item = await Testimonial.create({ ...req.body, clientImage });
    res.status(201).json(item);
  } catch (e) {
    res.status(500).json({ error: 'Erro ao criar depoimento' });
  }
};

export const update = async (req, res) => {
  try {
    const t = await Testimonial.findByPk(req.params.id);
    if (!t) return res.status(404).json({ error: 'Depoimento não encontrado' });
    const clientImage = req.file ? `/public/uploads/${req.file.filename}` : undefined;
    const data = { ...req.body };
    if (clientImage) data.clientImage = clientImage;
    await t.update(data);
    res.json(t);
  } catch (e) {
    res.status(500).json({ error: 'Erro ao atualizar depoimento' });
  }
};

export const remove = async (req, res) => {
  try {
    const deleted = await Testimonial.destroy({ where: { id: req.params.id } });
    if (!deleted) return res.status(404).json({ error: 'Depoimento não encontrado' });
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: 'Erro ao remover depoimento' });
  }
};
