import fs from 'fs';
import path from 'path';
import ejs from 'ejs';

export default async function generateStatic({ viewsDir, distDir, template, data }) {
  const tplPath = path.join(viewsDir, template);
  const html = await ejs.renderFile(tplPath, data, { async: true });
  if (!fs.existsSync(distDir)) fs.mkdirSync(distDir, { recursive: true });
  const outPath = path.join(distDir, 'index.html');
  fs.writeFileSync(outPath, html, 'utf-8');
  return outPath;
}
