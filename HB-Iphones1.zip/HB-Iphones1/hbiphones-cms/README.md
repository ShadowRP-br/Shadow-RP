# HB iPhones CMS (Node.js + Express + MongoDB)

CMS escalável para gerenciar o conteúdo do site de e-commerce da HB iPhones Ouro Branco. Fornece API pública para o site, painel administrativo com EJS/Bootstrap e geração de site estático para deploy em CDN/Netlify.

## Tecnologias
- Node.js 18+
- Express 4.18+
- MongoDB + Mongoose 7+
- Autenticação JWT (jsonwebtoken 9+) e hash de senhas (bcryptjs 2+)
- Segurança: helmet, rate limit, CORS, morgan
- Uploads: multer + sharp (miniaturas)
- E-mails: nodemailer
- Templates Admin: EJS + Bootstrap 5
- Validação: express-validator

## Estrutura
```
/project-root
├── /src
│   ├── /controllers
│   ├── /models
│   ├── /routes
│   ├── /middleware
│   ├── /utils
│   └── /views
├── /public (CSS, JS, /uploads)
├── /dist (site estático gerado)
├── server.js
├── .env.example
└── package.json
```

## Instalação
1. Clone este repositório (ou copie a pasta `hbiphones-cms`).
2. Instale as dependências:
```bash
npm install
```
3. Crie o arquivo `.env` baseado no `.env.example`:
```
PORT=3000
MONGO_URI=sua-string-do-mongodb-atlas
JWT_SECRET=uma-chave-segura
EMAIL_USER=seu-email@gmail.com
EMAIL_PASS=sua-senha-ou-app-password
WHATSAPP_NUMBER=5531999999999
BASE_URL=http://localhost:3000
```

## Banco de Dados (MongoDB Atlas)
- Crie um cluster no [MongoDB Atlas](https://www.mongodb.com/atlas/database).
- Copie a string de conexão (MONGO_URI) e adicione ao `.env`.

## Seed (Dados de Exemplo)
Popular o banco com usuários, produtos, benefícios, serviços, depoimentos e configurações iniciais:
```bash
npm run seed
```
Usuário admin padrão:
- E-mail: `admin@hbiphones.com`
- Senha: `admin123`

Usuário editor padrão:
- E-mail: `editor@hbiphones.com`
- Senha: `editor123`

## Executar
```bash
npm start
```
Acesse: `http://localhost:3000/`

## Autenticação
- Login: `POST /api/auth/login` com `{ email, password }`.
- O retorno contém `token` JWT. Use `Authorization: Bearer <token>` nas rotas protegidas.
- Papéis: `admin` (total) e `editor` (somente conteúdo).

## API Pública (exemplos)
- Produtos: `GET /api/products?page=1&limit=5&q=&category=`
- Benefícios: `GET /api/benefits`
- (Removido) Serviços e agendamentos: a loja não oferece mais serviços.
- Depoimentos: `GET /api/testimonials?minRating=4`
- Config: `GET /api/config`

## Rotas Admin (protegidas)
- Dashboard: `GET /admin` (requer Bearer Token; versão inicial usa JWT no header)
- Gerar site estático: `POST /admin/generate` (gera `/dist/index.html` a partir do template `static_home.ejs`)

## Uploads de Arquivos
- Diretório: `/public/uploads`
- Limites: até 5MB por arquivo, tipos JPEG/PNG/WebP.

## Integração com Site Público
- Consuma os dados via `/api/*`. Exemplo do WhatsApp:
  - `https://wa.me/${numero}?text=Interesse no ${produto.nome}`
- Alternativamente, gere o site estático com `POST /admin/generate` e faça deploy do conteúdo de `/dist` no Netlify.

## Próximos Passos (sugestão)
- Criar telas EJS completas para CRUDs (Produtos, Benefícios, Serviços, Depoimentos, Configurações, Perfil) com Bootstrap e SweetAlert2.
- Implementar ordenação por drag-and-drop em Benefícios (persistência no backend) e editor de texto rico simples.
- Integração opcional com Cloudinary para CDN de imagens.
- Relatórios/analytics (agregações MongoDB) e integração de pagamentos (Stripe).

## Licença
Projeto de exemplo educacional.
