-- Inicialização do banco para XAMPP MySQL/MariaDB
-- Ajustado para usuário do seu .env: HBiPhones21 / 1234 e DB hbiphones

CREATE DATABASE IF NOT EXISTS hbiphones
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

CREATE USER IF NOT EXISTS 'HBiPhones21'@'localhost' IDENTIFIED BY '1234';
ALTER USER 'HBiPhones21'@'localhost' IDENTIFIED BY '1234';
GRANT ALL PRIVILEGES ON hbiphones.* TO 'HBiPhones21'@'localhost';
FLUSH PRIVILEGES;
