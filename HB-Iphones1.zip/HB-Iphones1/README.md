# HB iPhones Ouro Branco – Website (100% estático)

Site moderno, minimalista e premium, inspirado no estilo Apple. Paleta: preto, branco e dourado. 100% estático (sem backend), pronto para GitHub Pages/Netlify/Vercel.

## Estrutura
- `index.html` – Home com hero, destaques, diferenciais, serviços, depoimentos, Instagram (via widget opcional) e mapa.
- `produtos.html` – Catálogo com filtros (modelo, condição, cor, armazenamento) e cards com botão de WhatsApp. Imagens oficiais da Apple no fallback.
- `servicos.html` – Serviços e seção “Antes e Depois” com comparador.
- `sobre.html` – História, valores e diferenciais.
- `contato.html` – Formulário simples (não envia para servidor) + mapa + horários.
- `assets/css/styles.css` – Estilos globais, responsividade e animações.
- `assets/js/main.js` – Menu mobile, WhatsApp, filtros/parcelamento, comparador e Instagram opcional.

## Como executar
Basta abrir `index.html` no navegador. Não há dependências ou servidor.

## Limpeza realizada (impertinentes removidos)
- Dependências de API foram eliminadas do front-end.
- Blog foi removido da navegação e do `sitemap.xml`.
- Se existir a pasta `server/` (backend), você pode apagá-la com segurança (não é utilizada).
- Se existir `blog.html`, você pode apagá-lo (não é utilizado).

## Personalização
1) WhatsApp
- Edite `assets/js/main.js` e ajuste `WHATSAPP_NUMBER`.

2) Instagram
- Use um widget (SnapWidget/Elfsight/LightWidget) e coloque a URL em `index.html` no elemento com `data-instagram-embed` (atributo `data-embed`).

3) Endereço e mapa
- Em `index.html` e `contato.html`, ajuste o iframe do Google Maps com o seu endereço.

4) Produtos e imagens
- Edite os cards em `produtos.html` (fallback) e as imagens da Home em `index.html`.
- Para filtros funcionarem, mantenha os atributos: `data-modelo`, `data-cor`, `data-armazenamento`, `data-condicao`.

## SEO
- `robots.txt` e `sitemap.xml` já configurados para GitHub Pages.
- JSON-LD (LocalBusiness) em `index.html` – ajuste `url`, `@id` e `image` conforme seu domínio.

## Deploy sugerido
- GitHub Pages: Settings → Pages → Branch `main` (root).
- Netlify/Vercel: arraste a pasta do projeto e publique.
